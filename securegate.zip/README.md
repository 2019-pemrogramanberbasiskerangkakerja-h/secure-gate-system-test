<h1><b>Pemprograman Berbasis Kerangka Kerja</b></h1>
<h2>Kelompok 11</h2>

<h3>SECURE GATE SYSTEM</h3>

<ul>
	<li> Aidil Abdillah Suyudi (05111640000047)</li>
	<li>Irham Muhammad Fadhil (05111640000085)</li>
	<li>Rahmad Yanuar MD      (05111640000159)</li>
</ul>

Tools yang digunakan :
<ul>
	<li><a href="apachefriends.org">XAMPP</a></li>
	<li><a href="expressjs.com">ExpressJS</a></li>
</ul>

<b>Cara Menjalankan :</b>

1. Clone repository ini.
2. Jalankan XAMPP.
3. Start Apache dan MySQL.
4. Jalankan Perintah "Node index.js"
5. Buka browser dan masuk ke http://localhost:3000/login
6. Buka CMD untuk melihat log saat gagal dan berhasil

<b>RESTful API</b>

API yang diterapkan adalah: 
- user
POST /users		- Add user
GET /users		- Get all users
GET /users/:userid	- Get info user
DELETE /users/:userid	- Delete user

- auth-login
POST /login		- login

- Gate
POST /gates		- add gate
GET /gates		- get all gates
GET /gates/:gateid	- get info gate
DELETE /gates/:gateid	- delete gate